// Object destructuring https://dev.to/sarah_chima/object-destructuring-in-es6-3fm
// import { addFirst, addLast, removeFirst, removeLast, contains } from './array-op.js';

// const arr = [1, 2, 3];

// const arr1 = removeLast(arr);
// const arr2 = removeFirst(arr1);

// console.log(`\nOriginal array`);
// console.log(arr);

// console.log(`\nRemoved from last and first`);
// console.log(arr2);

// const arr3 = addLast(arr2, 1);
// const arr4 = addFirst(arr3, 3);

// console.log(`\nOriginal array`);
// console.log(arr);

// console.log(`\nAdded to last and first`);
// console.log(arr4);

// console.log(`\nArray contains 4: ${contains(arr, 4)}`);

