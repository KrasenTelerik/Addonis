export const removeFirst = (arr) => {
  if (!Array.isArray(arr)) {
    throw new Error(`${arr} is not an Array!`);
  }

}

export const removeLast = (arr) => {
 
};

export const addFirst = (arr, element) => {
 
};

export const addLast = (arr, element) => {
   
};

export const contains = (arr, element) => {
 
};
