const defaultInfoMsg = 'No info provided!';

const info = (msg) => {

};

export default {
  info,
  // error,
  // success,
};
